
package net.mcreator.cickennuggetacsopupgradesmod.client.gui;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.Minecraft;

import net.mcreator.cickennuggetacsopupgradesmod.world.inventory.MagicCreation1Menu;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.T9Procedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.T8Procedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.T7Procedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.T6Procedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.T5Procedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.T4Procedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.T3Procedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.T2Procedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.T1Procedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.T13Procedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.T12Procedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.T11Procedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.T10Procedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.M9Procedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.M8Procedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.M7Procedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.M6Procedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.M5Procedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.M4Procedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.M3Procedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.M2Procedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.M1Procedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.M12Procedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.M11Procedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.M10Procedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.A5Procedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.A4Procedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.A3Procedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.A2Procedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.A1Procedure;
import net.mcreator.cickennuggetacsopupgradesmod.network.MagicCreation1ButtonMessage;
import net.mcreator.cickennuggetacsopupgradesmod.network.CickennuggetacsOpUpgradesModModVariables;
import net.mcreator.cickennuggetacsopupgradesmod.CickennuggetacsOpUpgradesModMod;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.systems.RenderSystem;

public class MagicCreation1Screen extends AbstractContainerScreen<MagicCreation1Menu> {
	private final Level world;
	private final int x, y, z;
	private final Player entity;

	public MagicCreation1Screen(MagicCreation1Menu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 0;
		this.imageHeight = 0;
	}

	private static final ResourceLocation texture = new ResourceLocation("cickennuggetacs_op_upgrades_mod:textures/magic_creation_1.png");

	@Override
	public void render(PoseStack ms, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(ms);
		super.render(ms, mouseX, mouseY, partialTicks);
		this.renderTooltip(ms, mouseX, mouseY);
	}

	@Override
	protected void renderBg(PoseStack ms, float partialTicks, int gx, int gy) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		RenderSystem.setShaderTexture(0, texture);
		this.blit(ms, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	public void containerTick() {
		super.containerTick();
	}

	@Override
	protected void renderLabels(PoseStack poseStack, int mouseX, int mouseY) {
		this.font.draw(poseStack, "Magic Usage Affinity", 57, -100, -16711783);
		this.font.draw(poseStack, "Magic Type", -134, -100, -13369447);
		this.font.draw(poseStack, "Magic Power", -141, -26, -13369447);
		this.font.draw(poseStack, "Magic Speed", 82, -26, -16711783);
		if (M1Procedure.execute(entity))
			this.font.draw(poseStack, "fire", -118, -79, -65536);
		if (M2Procedure.execute(entity))
			this.font.draw(poseStack, "water", -121, -80, -16777012);
		if (M3Procedure.execute(entity))
			this.font.draw(poseStack, "earth", -121, -79, -10079488);
		if (M4Procedure.execute(entity))
			this.font.draw(poseStack, "wind", -118, -79, -1);
		if (M5Procedure.execute(entity))
			this.font.draw(poseStack, "lightning", -132, -79, -256);
		if (M6Procedure.execute(entity))
			this.font.draw(poseStack, "light", -121, -79, -154);
		if (M7Procedure.execute(entity))
			this.font.draw(poseStack, "dark", -118, -79, -6750055);
		if (M8Procedure.execute(entity))
			this.font.draw(poseStack, "spirit", -124, -79, -13369498);
		if (M9Procedure.execute(entity))
			this.font.draw(poseStack, "blood", -121, -79, -3407872);
		if (M10Procedure.execute(entity))
			this.font.draw(poseStack, "spatial", -127, -79, -13434727);
		if (M11Procedure.execute(entity))
			this.font.draw(poseStack, "elemental", -132, -79, -16711936);
		if (M12Procedure.execute(entity))
			this.font.draw(poseStack, "beast", -121, -79, -39424);
		if (A1Procedure.execute(entity))
			this.font.draw(poseStack, "projectile", 82, -79, -16711834);
		if (A2Procedure.execute(entity))
			this.font.draw(poseStack, "armor enhancement", 64, -79, -13369498);
		if (A3Procedure.execute(entity))
			this.font.draw(poseStack, "sword enhancement", 64, -79, -16711834);
		if (A4Procedure.execute(entity))
			this.font.draw(poseStack, "magic sword", 79, -79, -16711834);
		if (A5Procedure.execute(entity))
			this.font.draw(poseStack, "summon", 94, -79, -16711834);
		this.font.draw(poseStack, "Summon Type", -138, 31, -16711834);
		this.font.draw(poseStack, "Magic Technique", 71, 30, -16711834);
		this.font.draw(poseStack, "Magic XZ Effect Area", -163, 77, -16711834);
		this.font.draw(poseStack, "Magic Y Effect Area", 60, 77, -16711834);
		this.font.draw(poseStack, "" + (int) ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Damage) + "", -119, -4, -16711885);
		this.font.draw(poseStack, "" + (int) ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Speed) + "", 100, -4, -16711885);
		if (T1Procedure.execute(entity))
			this.font.draw(poseStack, "Particles", 87, 56, -16711885);
		if (T2Procedure.execute(entity))
			this.font.draw(poseStack, "Beam", 99, 56, -16711885);
		if (T3Procedure.execute(entity))
			this.font.draw(poseStack, "Bomb", 99, 56, -16711885);
		if (T4Procedure.execute(entity))
			this.font.draw(poseStack, "shockwave", 87, 56, -16711885);
		if (T5Procedure.execute(entity))
			this.font.draw(poseStack, "skybeam", 92, 56, -16711885);
		if (T6Procedure.execute(entity))
			this.font.draw(poseStack, "laser", 97, 56, -16711885);
		if (T7Procedure.execute(entity))
			this.font.draw(poseStack, "wall", 99, 56, -16711885);
		if (T8Procedure.execute(entity))
			this.font.draw(poseStack, "Rush", 100, 56, -16711885);
		if (T9Procedure.execute(entity))
			this.font.draw(poseStack, "gatling", 93, 56, -16711885);
		if (T10Procedure.execute(entity))
			this.font.draw(poseStack, "flight", 93, 56, -16711885);
		if (T11Procedure.execute(entity))
			this.font.draw(poseStack, "Gateway", 91, 57, -16776961);
		if (T12Procedure.execute(entity))
			this.font.draw(poseStack, "teleport", 88, 57, -12829636);
		if (T13Procedure.execute(entity))
			this.font.draw(poseStack, "barrier dome", 78, 56, -16711732);
		this.font.draw(poseStack, "" + (int) ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Y) + "", 104, 101, -16724941);
		this.font.draw(poseStack, "" + (int) ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).XZ) + "", -111, 101, -16724941);
		this.font.draw(poseStack, "Size", -12, 59, -16711834);
		this.font.draw(poseStack, "" + (int) ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Size) + "", -3, 75, -16711834);
	}

	@Override
	public void onClose() {
		super.onClose();
		Minecraft.getInstance().keyboardHandler.setSendRepeatsToGui(false);
	}

	@Override
	public void init() {
		super.init();
		this.minecraft.keyboardHandler.setSendRepeatsToGui(true);
		this.addRenderableWidget(new Button(this.leftPos + -56, this.topPos + -84, 30, 20, new TextComponent(">"), e -> {
			if (true) {
				CickennuggetacsOpUpgradesModMod.PACKET_HANDLER.sendToServer(new MagicCreation1ButtonMessage(0, x, y, z));
				MagicCreation1ButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}));
		this.addRenderableWidget(new Button(this.leftPos + -184, this.topPos + -84, 30, 20, new TextComponent("<"), e -> {
			if (true) {
				CickennuggetacsOpUpgradesModMod.PACKET_HANDLER.sendToServer(new MagicCreation1ButtonMessage(1, x, y, z));
				MagicCreation1ButtonMessage.handleButtonAction(entity, 1, x, y, z);
			}
		}));
		this.addRenderableWidget(new Button(this.leftPos + 22, this.topPos + -84, 30, 20, new TextComponent("<"), e -> {
			if (true) {
				CickennuggetacsOpUpgradesModMod.PACKET_HANDLER.sendToServer(new MagicCreation1ButtonMessage(2, x, y, z));
				MagicCreation1ButtonMessage.handleButtonAction(entity, 2, x, y, z);
			}
		}));
		this.addRenderableWidget(new Button(this.leftPos + 163, this.topPos + -84, 30, 20, new TextComponent(">"), e -> {
			if (true) {
				CickennuggetacsOpUpgradesModMod.PACKET_HANDLER.sendToServer(new MagicCreation1ButtonMessage(3, x, y, z));
				MagicCreation1ButtonMessage.handleButtonAction(entity, 3, x, y, z);
			}
		}));
		this.addRenderableWidget(new Button(this.leftPos + 163, this.topPos + -9, 30, 20, new TextComponent(">"), e -> {
			if (true) {
				CickennuggetacsOpUpgradesModMod.PACKET_HANDLER.sendToServer(new MagicCreation1ButtonMessage(4, x, y, z));
				MagicCreation1ButtonMessage.handleButtonAction(entity, 4, x, y, z);
			}
		}));
		this.addRenderableWidget(new Button(this.leftPos + 22, this.topPos + -9, 30, 20, new TextComponent("<"), e -> {
			if (true) {
				CickennuggetacsOpUpgradesModMod.PACKET_HANDLER.sendToServer(new MagicCreation1ButtonMessage(5, x, y, z));
				MagicCreation1ButtonMessage.handleButtonAction(entity, 5, x, y, z);
			}
		}));
		this.addRenderableWidget(new Button(this.leftPos + -56, this.topPos + -9, 30, 20, new TextComponent(">"), e -> {
			if (true) {
				CickennuggetacsOpUpgradesModMod.PACKET_HANDLER.sendToServer(new MagicCreation1ButtonMessage(6, x, y, z));
				MagicCreation1ButtonMessage.handleButtonAction(entity, 6, x, y, z);
			}
		}));
		this.addRenderableWidget(new Button(this.leftPos + -184, this.topPos + -9, 30, 20, new TextComponent("<"), e -> {
			if (true) {
				CickennuggetacsOpUpgradesModMod.PACKET_HANDLER.sendToServer(new MagicCreation1ButtonMessage(7, x, y, z));
				MagicCreation1ButtonMessage.handleButtonAction(entity, 7, x, y, z);
			}
		}));
		this.addRenderableWidget(new Button(this.leftPos + -56, this.topPos + 51, 30, 20, new TextComponent(">"), e -> {
		}));
		this.addRenderableWidget(new Button(this.leftPos + -184, this.topPos + 50, 30, 20, new TextComponent("<"), e -> {
		}));
		this.addRenderableWidget(new Button(this.leftPos + 162, this.topPos + 51, 30, 20, new TextComponent(">"), e -> {
			if (true) {
				CickennuggetacsOpUpgradesModMod.PACKET_HANDLER.sendToServer(new MagicCreation1ButtonMessage(10, x, y, z));
				MagicCreation1ButtonMessage.handleButtonAction(entity, 10, x, y, z);
			}
		}));
		this.addRenderableWidget(new Button(this.leftPos + 22, this.topPos + 51, 30, 20, new TextComponent("<"), e -> {
			if (true) {
				CickennuggetacsOpUpgradesModMod.PACKET_HANDLER.sendToServer(new MagicCreation1ButtonMessage(11, x, y, z));
				MagicCreation1ButtonMessage.handleButtonAction(entity, 11, x, y, z);
			}
		}));
		this.addRenderableWidget(new Button(this.leftPos + -184, this.topPos + 95, 30, 20, new TextComponent("<"), e -> {
			if (true) {
				CickennuggetacsOpUpgradesModMod.PACKET_HANDLER.sendToServer(new MagicCreation1ButtonMessage(12, x, y, z));
				MagicCreation1ButtonMessage.handleButtonAction(entity, 12, x, y, z);
			}
		}));
		this.addRenderableWidget(new Button(this.leftPos + -57, this.topPos + 95, 30, 20, new TextComponent(">"), e -> {
			if (true) {
				CickennuggetacsOpUpgradesModMod.PACKET_HANDLER.sendToServer(new MagicCreation1ButtonMessage(13, x, y, z));
				MagicCreation1ButtonMessage.handleButtonAction(entity, 13, x, y, z);
			}
		}));
		this.addRenderableWidget(new Button(this.leftPos + 23, this.topPos + 94, 30, 20, new TextComponent("<"), e -> {
			if (true) {
				CickennuggetacsOpUpgradesModMod.PACKET_HANDLER.sendToServer(new MagicCreation1ButtonMessage(14, x, y, z));
				MagicCreation1ButtonMessage.handleButtonAction(entity, 14, x, y, z);
			}
		}));
		this.addRenderableWidget(new Button(this.leftPos + 162, this.topPos + 95, 30, 20, new TextComponent(">"), e -> {
			if (true) {
				CickennuggetacsOpUpgradesModMod.PACKET_HANDLER.sendToServer(new MagicCreation1ButtonMessage(15, x, y, z));
				MagicCreation1ButtonMessage.handleButtonAction(entity, 15, x, y, z);
			}
		}));
		this.addRenderableWidget(new Button(this.leftPos + -207, this.topPos + -117, 46, 20, new TextComponent("Back"), e -> {
			if (true) {
				CickennuggetacsOpUpgradesModMod.PACKET_HANDLER.sendToServer(new MagicCreation1ButtonMessage(16, x, y, z));
				MagicCreation1ButtonMessage.handleButtonAction(entity, 16, x, y, z);
			}
		}));
		this.addRenderableWidget(new Button(this.leftPos + 23, this.topPos + 72, 30, 20, new TextComponent(">"), e -> {
			if (true) {
				CickennuggetacsOpUpgradesModMod.PACKET_HANDLER.sendToServer(new MagicCreation1ButtonMessage(17, x, y, z));
				MagicCreation1ButtonMessage.handleButtonAction(entity, 17, x, y, z);
			}
		}));
		this.addRenderableWidget(new Button(this.leftPos + -56, this.topPos + 72, 30, 20, new TextComponent("<"), e -> {
			if (true) {
				CickennuggetacsOpUpgradesModMod.PACKET_HANDLER.sendToServer(new MagicCreation1ButtonMessage(18, x, y, z));
				MagicCreation1ButtonMessage.handleButtonAction(entity, 18, x, y, z);
			}
		}));
	}
}
