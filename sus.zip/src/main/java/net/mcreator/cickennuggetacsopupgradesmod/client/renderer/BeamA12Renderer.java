package net.mcreator.cickennuggetacsopupgradesmod.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;

import net.mcreator.cickennuggetacsopupgradesmod.entity.BeamA12Entity;
import net.mcreator.cickennuggetacsopupgradesmod.client.model.ModelBeam2;

public class BeamA12Renderer extends MobRenderer<BeamA12Entity, ModelBeam2<BeamA12Entity>> {
	public BeamA12Renderer(EntityRendererProvider.Context context) {
		super(context, new ModelBeam2(context.bakeLayer(ModelBeam2.LAYER_LOCATION)), 10f);
		this.addLayer(new EyesLayer<BeamA12Entity, ModelBeam2<BeamA12Entity>>(this) {
			@Override
			public RenderType renderType() {
				return RenderType.eyes(new ResourceLocation("cickennuggetacs_op_upgrades_mod:textures/fire.png"));
			}
		});
	}

	@Override
	public ResourceLocation getTextureLocation(BeamA12Entity entity) {
		return new ResourceLocation("cickennuggetacs_op_upgrades_mod:textures/invis.png");
	}
}
