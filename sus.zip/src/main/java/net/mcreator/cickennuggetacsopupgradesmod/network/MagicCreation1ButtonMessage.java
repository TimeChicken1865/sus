
package net.mcreator.cickennuggetacsopupgradesmod.network;

import net.minecraftforge.fmllegacy.network.NetworkEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.core.BlockPos;

import net.mcreator.cickennuggetacsopupgradesmod.world.inventory.MagicCreation1Menu;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.OpenMagicGUIProcedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.MagicYUpProcedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.MagicYDownProcedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.MagicXZUpProcedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.MagicXZDownProcedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.MagicTypeUpProcedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.MagicTypeDownProcedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.MagicTechniqueUpProcedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.MagicTechniqueDownProcedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.MagicSpeedUpForRealThisTimeProcedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.MagicSpeedDownProcedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.MagicSizeUpProcedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.MagicSizeDownProcedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.MagicDamageUpProcedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.MagicDamageDownProcedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.MagicAffinityUpProcedure;
import net.mcreator.cickennuggetacsopupgradesmod.procedures.MagicAffinityDownProcedure;
import net.mcreator.cickennuggetacsopupgradesmod.CickennuggetacsOpUpgradesModMod;

import java.util.function.Supplier;
import java.util.HashMap;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MagicCreation1ButtonMessage {
	private final int buttonID, x, y, z;

	public MagicCreation1ButtonMessage(FriendlyByteBuf buffer) {
		this.buttonID = buffer.readInt();
		this.x = buffer.readInt();
		this.y = buffer.readInt();
		this.z = buffer.readInt();
	}

	public MagicCreation1ButtonMessage(int buttonID, int x, int y, int z) {
		this.buttonID = buttonID;
		this.x = x;
		this.y = y;
		this.z = z;
	}

	public static void buffer(MagicCreation1ButtonMessage message, FriendlyByteBuf buffer) {
		buffer.writeInt(message.buttonID);
		buffer.writeInt(message.x);
		buffer.writeInt(message.y);
		buffer.writeInt(message.z);
	}

	public static void handler(MagicCreation1ButtonMessage message, Supplier<NetworkEvent.Context> contextSupplier) {
		NetworkEvent.Context context = contextSupplier.get();
		context.enqueueWork(() -> {
			Player entity = context.getSender();
			int buttonID = message.buttonID;
			int x = message.x;
			int y = message.y;
			int z = message.z;
			handleButtonAction(entity, buttonID, x, y, z);
		});
		context.setPacketHandled(true);
	}

	public static void handleButtonAction(Player entity, int buttonID, int x, int y, int z) {
		Level world = entity.level;
		HashMap guistate = MagicCreation1Menu.guistate;
		// security measure to prevent arbitrary chunk generation
		if (!world.hasChunkAt(new BlockPos(x, y, z)))
			return;
		if (buttonID == 0) {

			MagicTypeUpProcedure.execute(entity);
		}
		if (buttonID == 1) {

			MagicTypeDownProcedure.execute(entity);
		}
		if (buttonID == 2) {

			MagicAffinityDownProcedure.execute(entity);
		}
		if (buttonID == 3) {

			MagicAffinityUpProcedure.execute(entity);
		}
		if (buttonID == 4) {

			MagicSpeedUpForRealThisTimeProcedure.execute(entity);
		}
		if (buttonID == 5) {

			MagicSpeedDownProcedure.execute(entity);
		}
		if (buttonID == 6) {

			MagicDamageUpProcedure.execute(entity);
		}
		if (buttonID == 7) {

			MagicDamageDownProcedure.execute(entity);
		}
		if (buttonID == 10) {

			MagicTechniqueUpProcedure.execute(entity);
		}
		if (buttonID == 11) {

			MagicTechniqueDownProcedure.execute(entity);
		}
		if (buttonID == 12) {

			MagicXZDownProcedure.execute(entity);
		}
		if (buttonID == 13) {

			MagicXZUpProcedure.execute(entity);
		}
		if (buttonID == 14) {

			MagicYDownProcedure.execute(entity);
		}
		if (buttonID == 15) {

			MagicYUpProcedure.execute(entity);
		}
		if (buttonID == 16) {

			OpenMagicGUIProcedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 17) {

			MagicSizeUpProcedure.execute(entity);
		}
		if (buttonID == 18) {

			MagicSizeDownProcedure.execute(entity);
		}
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		CickennuggetacsOpUpgradesModMod.addNetworkMessage(MagicCreation1ButtonMessage.class, MagicCreation1ButtonMessage::buffer,
				MagicCreation1ButtonMessage::new, MagicCreation1ButtonMessage::handler);
	}
}
