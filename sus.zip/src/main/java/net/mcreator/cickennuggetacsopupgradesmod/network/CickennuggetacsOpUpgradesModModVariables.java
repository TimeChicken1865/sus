package net.mcreator.cickennuggetacsopupgradesmod.network;

import org.jline.terminal.Size;

import net.minecraftforge.fmllegacy.network.PacketDistributor;
import net.minecraftforge.fmllegacy.network.NetworkEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.Capability;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.nbt.Tag;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.Direction;
import net.minecraft.client.Minecraft;

import net.mcreator.cickennuggetacsopupgradesmod.CickennuggetacsOpUpgradesModMod;

import java.util.function.Supplier;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class CickennuggetacsOpUpgradesModModVariables {
	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		CickennuggetacsOpUpgradesModMod.addNetworkMessage(PlayerVariablesSyncMessage.class, PlayerVariablesSyncMessage::buffer,
				PlayerVariablesSyncMessage::new, PlayerVariablesSyncMessage::handler);
	}

	@SubscribeEvent
	public static void init(RegisterCapabilitiesEvent event) {
		event.register(PlayerVariables.class);
	}

	@Mod.EventBusSubscriber
	public static class EventBusVariableHandlers {
		@SubscribeEvent
		public static void onPlayerLoggedInSyncPlayerVariables(PlayerEvent.PlayerLoggedInEvent event) {
			if (!event.getPlayer().level.isClientSide())
				((PlayerVariables) event.getPlayer().getCapability(PLAYER_VARIABLES_CAPABILITY, null).orElse(new PlayerVariables()))
						.syncPlayerVariables(event.getPlayer());
		}

		@SubscribeEvent
		public static void onPlayerRespawnedSyncPlayerVariables(PlayerEvent.PlayerRespawnEvent event) {
			if (!event.getPlayer().level.isClientSide())
				((PlayerVariables) event.getPlayer().getCapability(PLAYER_VARIABLES_CAPABILITY, null).orElse(new PlayerVariables()))
						.syncPlayerVariables(event.getPlayer());
		}

		@SubscribeEvent
		public static void onPlayerChangedDimensionSyncPlayerVariables(PlayerEvent.PlayerChangedDimensionEvent event) {
			if (!event.getPlayer().level.isClientSide())
				((PlayerVariables) event.getPlayer().getCapability(PLAYER_VARIABLES_CAPABILITY, null).orElse(new PlayerVariables()))
						.syncPlayerVariables(event.getPlayer());
		}

		@SubscribeEvent
		public static void clonePlayer(PlayerEvent.Clone event) {
			event.getOriginal().revive();
			PlayerVariables original = ((PlayerVariables) event.getOriginal().getCapability(PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new PlayerVariables()));
			PlayerVariables clone = ((PlayerVariables) event.getEntity().getCapability(PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new PlayerVariables()));
			clone.mana = original.mana;
			clone.manamax = original.manamax;
			clone.MagicKeybind = original.MagicKeybind;
			clone.MagicType = original.MagicType;
			clone.Speed = original.Speed;
			clone.Damage = original.Damage;
			clone.XZ = original.XZ;
			clone.Y = original.Y;
			clone.Size = original.Size;
			clone.Immunity = original.Immunity;
			clone.S1 = original.S1;
			clone.S2 = original.S2;
			clone.S3 = original.S3;
			clone.S4 = original.S4;
			clone.S5 = original.S5;
			clone.S6 = original.S6;
			clone.D1 = original.D1;
			clone.D2 = original.D2;
			clone.D3 = original.D3;
			clone.D4 = original.D4;
			clone.D5 = original.D5;
			clone.D6 = original.D6;
			clone.Size1 = original.Size1;
			clone.Size2 = original.Size2;
			clone.Size3 = original.Size3;
			clone.Size4 = original.Size4;
			clone.Size5 = original.Size5;
			clone.Size6 = original.Size6;
			clone.m1 = original.m1;
			clone.m2 = original.m2;
			clone.m3 = original.m3;
			clone.m4 = original.m4;
			clone.m5 = original.m5;
			clone.m6 = original.m6;
			clone.A1 = original.A1;
			clone.A2 = original.A2;
			clone.A3 = original.A3;
			clone.A4 = original.A4;
			clone.A6 = original.A6;
			clone.T1 = original.T1;
			clone.T2 = original.T2;
			clone.T3 = original.T3;
			clone.T4 = original.T4;
			clone.T5 = original.T5;
			clone.T6 = original.T6;
			clone.X1 = original.X1;
			clone.X2 = original.X2;
			clone.X3 = original.X3;
			clone.X4 = original.X4;
			clone.X5 = original.X5;
			clone.X6 = original.X6;
			clone.Y1 = original.Y1;
			clone.Y2 = original.Y2;
			clone.Y3 = original.Y3;
			clone.Y4 = original.Y4;
			clone.Y5 = original.Y5;
			clone.Y6 = original.Y6;
			if (!event.isWasDeath()) {
				clone.A5 = original.A5;
			}
		}
	}

	public static final Capability<PlayerVariables> PLAYER_VARIABLES_CAPABILITY = CapabilityManager.get(new CapabilityToken<PlayerVariables>() {
	});

	@Mod.EventBusSubscriber
	private static class PlayerVariablesProvider implements ICapabilitySerializable<Tag> {
		@SubscribeEvent
		public static void onAttachCapabilities(AttachCapabilitiesEvent<Entity> event) {
			if (event.getObject() instanceof Player && !(event.getObject() instanceof FakePlayer))
				event.addCapability(new ResourceLocation("cickennuggetacs_op_upgrades_mod", "player_variables"), new PlayerVariablesProvider());
		}

		private final PlayerVariables playerVariables = new PlayerVariables();
		private final LazyOptional<PlayerVariables> instance = LazyOptional.of(() -> playerVariables);

		@Override
		public <T> LazyOptional<T> getCapability(Capability<T> cap, Direction side) {
			return cap == PLAYER_VARIABLES_CAPABILITY ? instance.cast() : LazyOptional.empty();
		}

		@Override
		public Tag serializeNBT() {
			return playerVariables.writeNBT();
		}

		@Override
		public void deserializeNBT(Tag nbt) {
			playerVariables.readNBT(nbt);
		}
	}

	public static class PlayerVariables {
		public double mana = 300.0;
		public double manamax = 300.0;
		public double MagicKeybind = 0;
		public double MagicType = 0.0;
		public double Speed = 1.0;
		public double Damage = 1.0;
		public double XZ = 0;
		public double Y = 0;
		public double Size = 0;
		public double Immunity = 0;
		public double S1 = 0;
		public double S2 = 0;
		public double S3 = 0;
		public double S4 = 0;
		public double S5 = 0;
		public double S6 = 0;
		public double D1 = 0;
		public double D2 = 0;
		public double D3 = 0;
		public double D4 = 0;
		public double D5 = 0;
		public double D6 = 0;
		public double Size1 = 0;
		public double Size2 = 0;
		public double Size3 = 0;
		public double Size4 = 0;
		public double Size5 = 0;
		public double Size6 = 0;
		public double m1 = 0;
		public double m2 = 0;
		public double m3 = 0;
		public double m4 = 0;
		public double m5 = 0;
		public double m6 = 0;
		public double A1 = 0;
		public double A2 = 0;
		public double A3 = 0;
		public double A4 = 0;
		public double A5 = 0;
		public double A6 = 0;
		public double T1 = 0;
		public double T2 = 0;
		public double T3 = 0;
		public double T4 = 0;
		public double T5 = 0;
		public double T6 = 0;
		public double X1 = 0;
		public double X2 = 0;
		public double X3 = 0;
		public double X4 = 0;
		public double X5 = 0;
		public double X6 = 0;
		public double Y1 = 0;
		public double Y2 = 0;
		public double Y3 = 0;
		public double Y4 = 0;
		public double Y5 = 0;
		public double Y6 = 0;

		public void syncPlayerVariables(Entity entity) {
			if (entity instanceof ServerPlayer serverPlayer)
				CickennuggetacsOpUpgradesModMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> serverPlayer),
						new PlayerVariablesSyncMessage(this));
		}

		public Tag writeNBT() {
			CompoundTag nbt = new CompoundTag();
			nbt.putDouble("mana", mana);
			nbt.putDouble("manamax", manamax);
			nbt.putDouble("MagicKeybind", MagicKeybind);
			nbt.putDouble("MagicType", MagicType);
			nbt.putDouble("Speed", Speed);
			nbt.putDouble("Damage", Damage);
			nbt.putDouble("XZ", XZ);
			nbt.putDouble("Y", Y);
			nbt.putDouble("Size", Size);
			nbt.putDouble("Immunity", Immunity);
			nbt.putDouble("S1", S1);
			nbt.putDouble("S2", S2);
			nbt.putDouble("S3", S3);
			nbt.putDouble("S4", S4);
			nbt.putDouble("S5", S5);
			nbt.putDouble("S6", S6);
			nbt.putDouble("D1", D1);
			nbt.putDouble("D2", D2);
			nbt.putDouble("D3", D3);
			nbt.putDouble("D4", D4);
			nbt.putDouble("D5", D5);
			nbt.putDouble("D6", D6);
			nbt.putDouble("Size1", Size1);
			nbt.putDouble("Size2", Size2);
			nbt.putDouble("Size3", Size3);
			nbt.putDouble("Size4", Size4);
			nbt.putDouble("Size5", Size5);
			nbt.putDouble("Size6", Size6);
			nbt.putDouble("m1", m1);
			nbt.putDouble("m2", m2);
			nbt.putDouble("m3", m3);
			nbt.putDouble("m4", m4);
			nbt.putDouble("m5", m5);
			nbt.putDouble("m6", m6);
			nbt.putDouble("A1", A1);
			nbt.putDouble("A2", A2);
			nbt.putDouble("A3", A3);
			nbt.putDouble("A4", A4);
			nbt.putDouble("A5", A5);
			nbt.putDouble("A6", A6);
			nbt.putDouble("T1", T1);
			nbt.putDouble("T2", T2);
			nbt.putDouble("T3", T3);
			nbt.putDouble("T4", T4);
			nbt.putDouble("T5", T5);
			nbt.putDouble("T6", T6);
			nbt.putDouble("X1", X1);
			nbt.putDouble("X2", X2);
			nbt.putDouble("X3", X3);
			nbt.putDouble("X4", X4);
			nbt.putDouble("X5", X5);
			nbt.putDouble("X6", X6);
			nbt.putDouble("Y1", Y1);
			nbt.putDouble("Y2", Y2);
			nbt.putDouble("Y3", Y3);
			nbt.putDouble("Y4", Y4);
			nbt.putDouble("Y5", Y5);
			nbt.putDouble("Y6", Y6);
			return nbt;
		}

		public void readNBT(Tag Tag) {
			CompoundTag nbt = (CompoundTag) Tag;
			mana = nbt.getDouble("mana");
			manamax = nbt.getDouble("manamax");
			MagicKeybind = nbt.getDouble("MagicKeybind");
			MagicType = nbt.getDouble("MagicType");
			Speed = nbt.getDouble("Speed");
			Damage = nbt.getDouble("Damage");
			XZ = nbt.getDouble("XZ");
			Y = nbt.getDouble("Y");
			Size = nbt.getDouble("Size");
			Immunity = nbt.getDouble("Immunity");
			S1 = nbt.getDouble("S1");
			S2 = nbt.getDouble("S2");
			S3 = nbt.getDouble("S3");
			S4 = nbt.getDouble("S4");
			S5 = nbt.getDouble("S5");
			S6 = nbt.getDouble("S6");
			D1 = nbt.getDouble("D1");
			D2 = nbt.getDouble("D2");
			D3 = nbt.getDouble("D3");
			D4 = nbt.getDouble("D4");
			D5 = nbt.getDouble("D5");
			D6 = nbt.getDouble("D6");
			Size1 = nbt.getDouble("Size1");
			Size2 = nbt.getDouble("Size2");
			Size3 = nbt.getDouble("Size3");
			Size4 = nbt.getDouble("Size4");
			Size5 = nbt.getDouble("Size5");
			Size6 = nbt.getDouble("Size6");
			m1 = nbt.getDouble("m1");
			m2 = nbt.getDouble("m2");
			m3 = nbt.getDouble("m3");
			m4 = nbt.getDouble("m4");
			m5 = nbt.getDouble("m5");
			m6 = nbt.getDouble("m6");
			A1 = nbt.getDouble("A1");
			A2 = nbt.getDouble("A2");
			A3 = nbt.getDouble("A3");
			A4 = nbt.getDouble("A4");
			A5 = nbt.getDouble("A5");
			A6 = nbt.getDouble("A6");
			T1 = nbt.getDouble("T1");
			T2 = nbt.getDouble("T2");
			T3 = nbt.getDouble("T3");
			T4 = nbt.getDouble("T4");
			T5 = nbt.getDouble("T5");
			T6 = nbt.getDouble("T6");
			X1 = nbt.getDouble("X1");
			X2 = nbt.getDouble("X2");
			X3 = nbt.getDouble("X3");
			X4 = nbt.getDouble("X4");
			X5 = nbt.getDouble("X5");
			X6 = nbt.getDouble("X6");
			Y1 = nbt.getDouble("Y1");
			Y2 = nbt.getDouble("Y2");
			Y3 = nbt.getDouble("Y3");
			Y4 = nbt.getDouble("Y4");
			Y5 = nbt.getDouble("Y5");
			Y6 = nbt.getDouble("Y6");
		}
	}

	public static class PlayerVariablesSyncMessage {
		public PlayerVariables data;

		public PlayerVariablesSyncMessage(FriendlyByteBuf buffer) {
			this.data = new PlayerVariables();
			this.data.readNBT(buffer.readNbt());
		}

		public PlayerVariablesSyncMessage(PlayerVariables data) {
			this.data = data;
		}

		public static void buffer(PlayerVariablesSyncMessage message, FriendlyByteBuf buffer) {
			buffer.writeNbt((CompoundTag) message.data.writeNBT());
		}

		public static void handler(PlayerVariablesSyncMessage message, Supplier<NetworkEvent.Context> contextSupplier) {
			NetworkEvent.Context context = contextSupplier.get();
			context.enqueueWork(() -> {
				if (!context.getDirection().getReceptionSide().isServer()) {
					PlayerVariables variables = ((PlayerVariables) Minecraft.getInstance().player.getCapability(PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new PlayerVariables()));
					variables.mana = message.data.mana;
					variables.manamax = message.data.manamax;
					variables.MagicKeybind = message.data.MagicKeybind;
					variables.MagicType = message.data.MagicType;
					variables.Speed = message.data.Speed;
					variables.Damage = message.data.Damage;
					variables.XZ = message.data.XZ;
					variables.Y = message.data.Y;
					variables.Size = message.data.Size;
					variables.Immunity = message.data.Immunity;
					variables.S1 = message.data.S1;
					variables.S2 = message.data.S2;
					variables.S3 = message.data.S3;
					variables.S4 = message.data.S4;
					variables.S5 = message.data.S5;
					variables.S6 = message.data.S6;
					variables.D1 = message.data.D1;
					variables.D2 = message.data.D2;
					variables.D3 = message.data.D3;
					variables.D4 = message.data.D4;
					variables.D5 = message.data.D5;
					variables.D6 = message.data.D6;
					variables.Size1 = message.data.Size1;
					variables.Size2 = message.data.Size2;
					variables.Size3 = message.data.Size3;
					variables.Size4 = message.data.Size4;
					variables.Size5 = message.data.Size5;
					variables.Size6 = message.data.Size6;
					variables.m1 = message.data.m1;
					variables.m2 = message.data.m2;
					variables.m3 = message.data.m3;
					variables.m4 = message.data.m4;
					variables.m5 = message.data.m5;
					variables.m6 = message.data.m6;
					variables.A1 = message.data.A1;
					variables.A2 = message.data.A2;
					variables.A3 = message.data.A3;
					variables.A4 = message.data.A4;
					variables.A5 = message.data.A5;
					variables.A6 = message.data.A6;
					variables.T1 = message.data.T1;
					variables.T2 = message.data.T2;
					variables.T3 = message.data.T3;
					variables.T4 = message.data.T4;
					variables.T5 = message.data.T5;
					variables.T6 = message.data.T6;
					variables.X1 = message.data.X1;
					variables.X2 = message.data.X2;
					variables.X3 = message.data.X3;
					variables.X4 = message.data.X4;
					variables.X5 = message.data.X5;
					variables.X6 = message.data.X6;
					variables.Y1 = message.data.Y1;
					variables.Y2 = message.data.Y2;
					variables.Y3 = message.data.Y3;
					variables.Y4 = message.data.Y4;
					variables.Y5 = message.data.Y5;
					variables.Y6 = message.data.Y6;
				}
			});
			context.setPacketHandled(true);
		}
	}
}
