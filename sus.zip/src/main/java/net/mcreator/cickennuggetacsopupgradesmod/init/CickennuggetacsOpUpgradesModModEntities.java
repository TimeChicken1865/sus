
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.cickennuggetacsopupgradesmod.init;

import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.cickennuggetacsopupgradesmod.entity.FireeeeEntity;
import net.mcreator.cickennuggetacsopupgradesmod.entity.FireS4Entity;
import net.mcreator.cickennuggetacsopupgradesmod.entity.FireS3Entity;
import net.mcreator.cickennuggetacsopupgradesmod.entity.FireS2Entity;
import net.mcreator.cickennuggetacsopupgradesmod.entity.FireS1Entity;
import net.mcreator.cickennuggetacsopupgradesmod.entity.BeamEntity;
import net.mcreator.cickennuggetacsopupgradesmod.entity.BeamA14Entity;
import net.mcreator.cickennuggetacsopupgradesmod.entity.BeamA13Entity;
import net.mcreator.cickennuggetacsopupgradesmod.entity.BeamA12Entity;
import net.mcreator.cickennuggetacsopupgradesmod.entity.BeamA11Entity;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class CickennuggetacsOpUpgradesModModEntities {
	private static final List<EntityType<?>> REGISTRY = new ArrayList<>();
	public static final EntityType<FireS1Entity> FIRE_S_1 = register("entitybulletfire_s_1",
			EntityType.Builder.<FireS1Entity>of(FireS1Entity::new, MobCategory.MISC).setCustomClientFactory(FireS1Entity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final EntityType<FireS2Entity> FIRE_S_2 = register("entitybulletfire_s_2",
			EntityType.Builder.<FireS2Entity>of(FireS2Entity::new, MobCategory.MISC).setCustomClientFactory(FireS2Entity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final EntityType<FireeeeEntity> FIREEEE = register("fireeee",
			EntityType.Builder.<FireeeeEntity>of(FireeeeEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(FireeeeEntity::new).fireImmune().sized(0f, 0f));
	public static final EntityType<FireS3Entity> FIRE_S_3 = register("entitybulletfire_s_3",
			EntityType.Builder.<FireS3Entity>of(FireS3Entity::new, MobCategory.MISC).setCustomClientFactory(FireS3Entity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final EntityType<FireS4Entity> FIRE_S_4 = register("entitybulletfire_s_4",
			EntityType.Builder.<FireS4Entity>of(FireS4Entity::new, MobCategory.MISC).setCustomClientFactory(FireS4Entity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final EntityType<BeamEntity> BEAM = register("entitybulletbeam",
			EntityType.Builder.<BeamEntity>of(BeamEntity::new, MobCategory.MISC).setCustomClientFactory(BeamEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final EntityType<BeamA11Entity> BEAM_A_11 = register("beam_a_11",
			EntityType.Builder.<BeamA11Entity>of(BeamA11Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(BeamA11Entity::new).fireImmune().sized(10f, 10f));
	public static final EntityType<BeamA12Entity> BEAM_A_12 = register("beam_a_12",
			EntityType.Builder.<BeamA12Entity>of(BeamA12Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(BeamA12Entity::new).fireImmune().sized(10f, 10f));
	public static final EntityType<BeamA13Entity> BEAM_A_13 = register("beam_a_13",
			EntityType.Builder.<BeamA13Entity>of(BeamA13Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(BeamA13Entity::new).fireImmune().sized(10f, 10f));
	public static final EntityType<BeamA14Entity> BEAM_A_14 = register("beam_a_14",
			EntityType.Builder.<BeamA14Entity>of(BeamA14Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(BeamA14Entity::new).fireImmune().sized(10f, 10f));

	private static <T extends Entity> EntityType<T> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		EntityType<T> entityType = (EntityType<T>) entityTypeBuilder.build(registryname).setRegistryName(registryname);
		REGISTRY.add(entityType);
		return entityType;
	}

	@SubscribeEvent
	public static void registerEntities(RegistryEvent.Register<EntityType<?>> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new EntityType[0]));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			FireeeeEntity.init();
			BeamA11Entity.init();
			BeamA12Entity.init();
			BeamA13Entity.init();
			BeamA14Entity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(FIREEEE, FireeeeEntity.createAttributes().build());
		event.put(BEAM_A_11, BeamA11Entity.createAttributes().build());
		event.put(BEAM_A_12, BeamA12Entity.createAttributes().build());
		event.put(BEAM_A_13, BeamA13Entity.createAttributes().build());
		event.put(BEAM_A_14, BeamA14Entity.createAttributes().build());
	}
}
