
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.cickennuggetacsopupgradesmod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;

import net.mcreator.cickennuggetacsopupgradesmod.item.FireS4Item;
import net.mcreator.cickennuggetacsopupgradesmod.item.FireS3Item;
import net.mcreator.cickennuggetacsopupgradesmod.item.FireS2Item;
import net.mcreator.cickennuggetacsopupgradesmod.item.FireS1Item;
import net.mcreator.cickennuggetacsopupgradesmod.item.BeamItem;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class CickennuggetacsOpUpgradesModModItems {
	private static final List<Item> REGISTRY = new ArrayList<>();
	public static final Item FIRE_S_1 = register(new FireS1Item());
	public static final Item FIRE_S_2 = register(new FireS2Item());
	public static final Item FIREEEE = register(
			new SpawnEggItem(CickennuggetacsOpUpgradesModModEntities.FIREEEE, -1, -1, new Item.Properties().tab(null))
					.setRegistryName("fireeee_spawn_egg"));
	public static final Item FIRE_S_3 = register(new FireS3Item());
	public static final Item FIRE_S_4 = register(new FireS4Item());
	public static final Item BEAM = register(new BeamItem());
	public static final Item BEAM_A_11 = register(
			new SpawnEggItem(CickennuggetacsOpUpgradesModModEntities.BEAM_A_11, -1, -1, new Item.Properties().tab(null))
					.setRegistryName("beam_a_11_spawn_egg"));
	public static final Item BEAM_A_12 = register(
			new SpawnEggItem(CickennuggetacsOpUpgradesModModEntities.BEAM_A_12, -1, -1, new Item.Properties().tab(null))
					.setRegistryName("beam_a_12_spawn_egg"));
	public static final Item BEAM_A_13 = register(
			new SpawnEggItem(CickennuggetacsOpUpgradesModModEntities.BEAM_A_13, -1, -1, new Item.Properties().tab(null))
					.setRegistryName("beam_a_13_spawn_egg"));
	public static final Item BEAM_A_14 = register(
			new SpawnEggItem(CickennuggetacsOpUpgradesModModEntities.BEAM_A_14, -1, -1, new Item.Properties().tab(null))
					.setRegistryName("beam_a_14_spawn_egg"));

	private static Item register(Item item) {
		REGISTRY.add(item);
		return item;
	}

	@SubscribeEvent
	public static void registerItems(RegistryEvent.Register<Item> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new Item[0]));
	}
}
