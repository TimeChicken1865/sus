
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.cickennuggetacsopupgradesmod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.cickennuggetacsopupgradesmod.client.renderer.FireeeeRenderer;
import net.mcreator.cickennuggetacsopupgradesmod.client.renderer.FireS4Renderer;
import net.mcreator.cickennuggetacsopupgradesmod.client.renderer.FireS3Renderer;
import net.mcreator.cickennuggetacsopupgradesmod.client.renderer.FireS2Renderer;
import net.mcreator.cickennuggetacsopupgradesmod.client.renderer.FireS1Renderer;
import net.mcreator.cickennuggetacsopupgradesmod.client.renderer.BeamA14Renderer;
import net.mcreator.cickennuggetacsopupgradesmod.client.renderer.BeamA13Renderer;
import net.mcreator.cickennuggetacsopupgradesmod.client.renderer.BeamA12Renderer;
import net.mcreator.cickennuggetacsopupgradesmod.client.renderer.BeamA11Renderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class CickennuggetacsOpUpgradesModModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(CickennuggetacsOpUpgradesModModEntities.FIRE_S_1, FireS1Renderer::new);
		event.registerEntityRenderer(CickennuggetacsOpUpgradesModModEntities.FIRE_S_2, FireS2Renderer::new);
		event.registerEntityRenderer(CickennuggetacsOpUpgradesModModEntities.FIREEEE, FireeeeRenderer::new);
		event.registerEntityRenderer(CickennuggetacsOpUpgradesModModEntities.FIRE_S_3, FireS3Renderer::new);
		event.registerEntityRenderer(CickennuggetacsOpUpgradesModModEntities.FIRE_S_4, FireS4Renderer::new);
		event.registerEntityRenderer(CickennuggetacsOpUpgradesModModEntities.BEAM, ThrownItemRenderer::new);
		event.registerEntityRenderer(CickennuggetacsOpUpgradesModModEntities.BEAM_A_11, BeamA11Renderer::new);
		event.registerEntityRenderer(CickennuggetacsOpUpgradesModModEntities.BEAM_A_12, BeamA12Renderer::new);
		event.registerEntityRenderer(CickennuggetacsOpUpgradesModModEntities.BEAM_A_13, BeamA13Renderer::new);
		event.registerEntityRenderer(CickennuggetacsOpUpgradesModModEntities.BEAM_A_14, BeamA14Renderer::new);
	}
}
