package net.mcreator.cickennuggetacsopupgradesmod.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;

import net.mcreator.cickennuggetacsopupgradesmod.network.CickennuggetacsOpUpgradesModModVariables;

import java.util.stream.Collectors;
import java.util.List;
import java.util.Comparator;

public class BeamWhileProjectileFlyingTickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity imediatesourceentity) {
		if (entity == null || imediatesourceentity == null)
			return;
		imediatesourceentity.setNoGravity((true));
		if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).A1 == 1) {
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Size1 == 2) {
				{
					final Vec3 _center = new Vec3(x, y, z);
					List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(2 / 2d), e -> true).stream()
							.sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).collect(Collectors.toList());
					for (Entity entityiterator : _entfound) {
						if ((entityiterator.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Immunity != (entity
										.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
										.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Immunity) {
							entityiterator.setSecondsOnFire(15);
							if (entity instanceof LivingEntity _entity)
								_entity.hurt(new DamageSource("FireBeam").bypassArmor(),
										(float) (2 + (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
												.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).D1));
						}
					}
				}
			}
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Size1 == 3) {
				{
					final Vec3 _center = new Vec3(x, y, z);
					List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(4 / 2d), e -> true).stream()
							.sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).collect(Collectors.toList());
					for (Entity entityiterator : _entfound) {
						if ((entityiterator.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Immunity != (entity
										.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
										.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Immunity) {
							entityiterator.setSecondsOnFire(15);
							if (entity instanceof LivingEntity _entity)
								_entity.hurt(new DamageSource("FireBeam").bypassArmor(),
										(float) (4 + (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
												.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).D1));
						}
					}
				}
			}
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Size1 == 4) {
				{
					final Vec3 _center = new Vec3(x, y, z);
					List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(8 / 2d), e -> true).stream()
							.sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).collect(Collectors.toList());
					for (Entity entityiterator : _entfound) {
						if ((entityiterator.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Immunity != (entity
										.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
										.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Immunity) {
							entityiterator.setSecondsOnFire(15);
							if (entity instanceof LivingEntity _entity)
								_entity.hurt(new DamageSource("FireBeam").bypassArmor(),
										(float) (8 + (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
												.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).D1));
						}
					}
				}
			}
		}
	}
}
