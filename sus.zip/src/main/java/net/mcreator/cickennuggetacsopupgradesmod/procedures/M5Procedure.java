package net.mcreator.cickennuggetacsopupgradesmod.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.cickennuggetacsopupgradesmod.network.CickennuggetacsOpUpgradesModModVariables;

public class M5Procedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).MagicKeybind == 1) {
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).m1 == 5) {
				return true;
			}
		}
		if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).MagicKeybind == 2) {
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).m2 == 5) {
				return true;
			}
		}
		if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).MagicKeybind == 3) {
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).m3 == 5) {
				return true;
			}
		}
		if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).MagicKeybind == 4) {
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).m4 == 5) {
				return true;
			}
		}
		if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).MagicKeybind == 5) {
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).m5 == 5) {
				return true;
			}
		}
		if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).MagicKeybind == 6) {
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).m6 == 5) {
				return true;
			}
		}
		return false;
	}
}
